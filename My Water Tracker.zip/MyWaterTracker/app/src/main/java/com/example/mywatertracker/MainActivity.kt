package com.example.mywatertracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.mywatertracker.ui.theme.MyWaterTrackerTheme
import android.content.Intent
import android.widget.Button


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {

            val serviceIntent = Intent(this, WaterTrackerService::class.java)
            startForegroundService(serviceIntent)

            val addWaterButton: Button = findViewById(R.id.add_water_button)
            addWaterButton.setOnClickListener {
                val amount = 250 // Change the amount as needed
                val serviceIntent = Intent(this@MainActivity, WaterTrackerService::class.java)
                serviceIntent.putExtra(EXTRA_WATER_AMOUNT, amount)
                startService(serviceIntent)
            }


            MyWaterTrackerTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    Greeting("Android")
                }
            }
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MyWaterTrackerTheme {
        Greeting("Android")
    }
}