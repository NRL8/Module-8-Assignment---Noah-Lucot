package com.example.mywatertracker

import android.app.Service
import android.content.Intent
import android.os.IBinder
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import android.app.Notification
import android.app.PendingIntent


class WaterTrackerService : Service() {

    private val NOTIFICATION_ID = 1
    private val EXTRA_WATER_AMOUNT = "extra_water_amount"
    private val DECREASE_INTERVAL_MS = 5000 // 5 seconds

    private var waterLevel = 0
    private val handler = Handler()

    private const val CHANNEL_ID = "water_tracker_channel"

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Water Tracker",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val notificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun showNotification() {
        val notificationBuilder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("My Water Tracker")
            .setContentText("Current water level: $waterLevel ml")
            .setSmallIcon(R.drawable.ic_water_drop)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        val notificationManager = NotificationManagerCompat.from(this)
        notificationManager.notify(NOTIFICATION_ID, notificationBuilder.build())
    }

    private fun startForegroundService() {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0)

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("My Water Tracker")
            .setContentText("Tracking water level...")
            .setSmallIcon(R.drawable.ic_water_drop)
            .setContentIntent(pendingIntent)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun updateWaterLevel(amount: Int) {
        waterLevel += amount
        showNotification()
    }

    private val decreaseRunnable = object : Runnable {
        override fun run() {
            waterLevel -= 100 // Decrease water level by 100 ml every 5 seconds
            showNotification()
            handler.postDelayed(this, DECREASE_INTERVAL_MS.toLong())
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForegroundService()
        handler.postDelayed(decreaseRunnable, DECREASE_INTERVAL_MS.toLong())
    }

    private fun handleFluidAddition(intent: Intent) {
        if (intent.hasExtra(EXTRA_WATER_AMOUNT)) {
            val amount = intent.getIntExtra(EXTRA_WATER_AMOUNT, 0)
            updateWaterLevel(amount)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let { handleFluidAddition(it) }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(decreaseRunnable)
    }

    override fun onBind(intent: Intent): IBinder {
        TODO("Return the communication channel to the service.")
    }
}